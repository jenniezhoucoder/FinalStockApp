//
//  Stock.swift
//  stockApp
//
//  Created by junni zhou on 12/10/22.
//

import Foundation

class Stock{
    var name: String;
    var symbol: String;
    var price: String;
    init(name: String, symbol: String, price: String) {
        self.name = name
        self.symbol = symbol
        self.price = price
    }
}
