//
//  ViewController.swift
//  stockApp
//
//  Created by junni zhou on 12/10/22.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tblView: UITableView!
    var stocks : [Stock] = [Stock]()
    var indexSelected = 0
    //var tempsymbol = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getStockPrice()
        
    }
        
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return stocks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let stock = stocks[indexPath.row]
        cell.textLabel?.text = stock.name + " , " + stock.symbol + " , " + stock.price
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        indexSelected = indexPath.row
        performSegue(withIdentifier: "segueDetails", sender: self)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

            if(segue.identifier == "segueDetails"){
                let destVC = segue.destination as! DetailsViewController
                let selectedStock = stocks[indexSelected]
                destVC.name = selectedStock.name
                destVC.symbol = selectedStock.symbol
                destVC.price = selectedStock.price
            }

        }
    
    
    func getStockPrice() {
        var url = "https://us-central1-whatsapp-analytics-2de0e.cloudfunctions.net/app/allstocks"
        self.stocks = [Stock]()
        AF.request(url).responseJSON { responseData in

            print(responseData)
            if responseData.error != nil {
                print(responseData.error!)
                return
            }
            let stockData = JSON(responseData.data as Any)

            for stock in stockData{
                let stockJSON = JSON(stock.1)
                let Name = stockJSON["CompanyName"].stringValue
                let Symbol = stockJSON["Symbol"].stringValue
                let Price = stockJSON["Price"].stringValue
                self.stocks.append(Stock(name: Name, symbol: Symbol, price: Price))
            }
            self.tblView.reloadData()
        }
    }
}
