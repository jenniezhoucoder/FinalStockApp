//
//  DetailsViewController.swift
//  stockApp
//
//  Created by junni zhou on 12/10/22.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner

class DetailsViewController: UIViewController {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblSymbol: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    var stocks: [Stock] = [Stock]()
    var name: String = ""
    var price: String = ""
    var symbol: String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblName?.text = "Company Name: \(name)"
        lblSymbol?.text = "Company Symbol: \(symbol)"
        lblPrice?.text = "Stock Price: \(price)"
        getStockPrice()
    }
    
    func getStockPrice() {
        var url = "https://us-central1-whatsapp-analytics-2de0e.cloudfunctions.net/app/getstock?symbol="
        url+=symbol
        AF.request(url).responseJSON { responseData in
            
            SwiftSpinner.hide()
            
            if responseData.error != nil {
                print(responseData.error!)
                return
            }
            print(responseData)
            
        }
    }
}
